namespace Portal.Web.Models;

public sealed class CameraCriteria
{
    public string SiteId { get; set; } = string.Empty;
    public string CameraId { get; set; } = string.Empty;

    public string CriteriaTitle { get; set; } = "Qualified Criteria";
    public string CriteriaDescription { get; set; } = "Use site SOP for qualification decisions.";

    public DateTimeOffset UpdatedAtUtc { get; set; }
}
