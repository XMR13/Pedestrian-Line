namespace Portal.Web.Models;

public sealed class EventRecord
{
    public string EventUid { get; set; } = string.Empty;
    public string RunUid { get; set; } = string.Empty;

    public string SiteId { get; set; } = string.Empty;
    public string CameraId { get; set; } = string.Empty;

    public DateTimeOffset? OccurredAtUtc { get; set; }
    public int? FrameIndex { get; set; }
    public double? VideoTimeS { get; set; }

    public string? Direction { get; set; }
    public int? TrackId { get; set; }

    public int? ClassId { get; set; }
    public string? ClassName { get; set; }
    public double? Confidence { get; set; }

    public string? BboxJson { get; set; }

    public string? LineMode { get; set; }
    public string? OccurredAtUtcSource { get; set; }

    public string? ThumbPath { get; set; }
    public string? ScenePath { get; set; }

    public DateTimeOffset UpdatedAtUtc { get; set; }

    public RunRecord? Run { get; set; }
    public EventReview? Review { get; set; }
}
