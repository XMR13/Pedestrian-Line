namespace Portal.Web.Models;

public sealed class EventReview
{
    public string EventUid { get; set; } = string.Empty;
    public string ReviewStatus { get; set; } = ReviewStatuses.Pending;

    public DateTimeOffset? ReviewedAtUtc { get; set; }
    public string? ReviewedBy { get; set; }
    public string? Notes { get; set; }

    public DateTimeOffset UpdatedAtUtc { get; set; }

    public EventRecord? Event { get; set; }
}

public static class ReviewStatuses
{
    public const string Pending = "PENDING";
    public const string Qualified = "QUALIFIED";
    public const string NotQualified = "NOT_QUALIFIED";

    public static readonly IReadOnlySet<string> All = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        Pending,
        Qualified,
        NotQualified,
    };
}
