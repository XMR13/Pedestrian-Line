namespace Portal.Web.Models;

public sealed class RunRecord
{
    public string RunUid { get; set; } = string.Empty;
    public string SiteId { get; set; } = string.Empty;
    public string CameraId { get; set; } = string.Empty;

    public DateTimeOffset? StartedAtUtc { get; set; }
    public DateTimeOffset? EndedAtUtc { get; set; }

    public string? SourceType { get; set; }
    public string? SourceValue { get; set; }

    public string? ModelVersion { get; set; }
    public string? CfgVersion { get; set; }

    public string? LineMode { get; set; }
    public string? LineId { get; set; }

    public double? Fps { get; set; }
    public int? FrameWidth { get; set; }
    public int? FrameHeight { get; set; }

    public string? HealthSummaryJson { get; set; }
    public string? ReportCsvRelpath { get; set; }

    public DateTimeOffset UpdatedAtUtc { get; set; }

    public List<EventRecord> Events { get; set; } = new();
}
