using Microsoft.EntityFrameworkCore;
using Portal.Web.Models;

namespace Portal.Web.Data;

public sealed class PortalDbContext(DbContextOptions<PortalDbContext> options) : DbContext(options)
{
    public DbSet<RunRecord> Runs => Set<RunRecord>();
    public DbSet<EventRecord> Events => Set<EventRecord>();
    public DbSet<EventReview> EventReviews => Set<EventReview>();
    public DbSet<CameraCriteria> CameraCriteria => Set<CameraCriteria>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<RunRecord>(entity =>
        {
            entity.ToTable("runs");
            entity.HasKey(x => x.RunUid);
            entity.Property(x => x.RunUid).HasColumnName("run_uid").HasMaxLength(64);
            entity.Property(x => x.SiteId).HasColumnName("site_id").HasMaxLength(100);
            entity.Property(x => x.CameraId).HasColumnName("camera_id").HasMaxLength(100);
            entity.Property(x => x.StartedAtUtc).HasColumnName("started_at_utc");
            entity.Property(x => x.EndedAtUtc).HasColumnName("ended_at_utc");
            entity.Property(x => x.SourceType).HasColumnName("source_type").HasMaxLength(40);
            entity.Property(x => x.SourceValue).HasColumnName("source_value").HasMaxLength(400);
            entity.Property(x => x.ModelVersion).HasColumnName("model_version").HasMaxLength(200);
            entity.Property(x => x.CfgVersion).HasColumnName("cfg_version").HasMaxLength(200);
            entity.Property(x => x.LineMode).HasColumnName("line_mode").HasMaxLength(40);
            entity.Property(x => x.LineId).HasColumnName("line_id").HasMaxLength(120);
            entity.Property(x => x.Fps).HasColumnName("fps");
            entity.Property(x => x.FrameWidth).HasColumnName("frame_width");
            entity.Property(x => x.FrameHeight).HasColumnName("frame_height");
            entity.Property(x => x.HealthSummaryJson).HasColumnName("health_summary_json");
            entity.Property(x => x.ReportCsvRelpath).HasColumnName("report_csv_relpath").HasMaxLength(260);
            entity.Property(x => x.UpdatedAtUtc).HasColumnName("updated_at_utc");

            entity.HasIndex(x => new { x.SiteId, x.CameraId, x.StartedAtUtc }).HasDatabaseName("ix_runs_site_camera_start");
        });

        modelBuilder.Entity<EventRecord>(entity =>
        {
            entity.ToTable("events");
            entity.HasKey(x => x.EventUid);
            entity.Property(x => x.EventUid).HasColumnName("event_uid").HasMaxLength(64);
            entity.Property(x => x.RunUid).HasColumnName("run_uid").HasMaxLength(64);
            entity.Property(x => x.SiteId).HasColumnName("site_id").HasMaxLength(100);
            entity.Property(x => x.CameraId).HasColumnName("camera_id").HasMaxLength(100);
            entity.Property(x => x.OccurredAtUtc).HasColumnName("occurred_at_utc");
            entity.Property(x => x.FrameIndex).HasColumnName("frame_index");
            entity.Property(x => x.VideoTimeS).HasColumnName("video_time_s");
            entity.Property(x => x.Direction).HasColumnName("direction").HasMaxLength(16);
            entity.Property(x => x.TrackId).HasColumnName("track_id");
            entity.Property(x => x.ClassId).HasColumnName("class_id");
            entity.Property(x => x.ClassName).HasColumnName("class_name").HasMaxLength(80);
            entity.Property(x => x.Confidence).HasColumnName("confidence");
            entity.Property(x => x.BboxJson).HasColumnName("bbox_json").HasMaxLength(120);
            entity.Property(x => x.LineMode).HasColumnName("line_mode").HasMaxLength(40);
            entity.Property(x => x.OccurredAtUtcSource).HasColumnName("occurred_at_utc_source").HasMaxLength(40);
            entity.Property(x => x.ThumbPath).HasColumnName("thumb_path").HasMaxLength(260);
            entity.Property(x => x.ScenePath).HasColumnName("scene_path").HasMaxLength(260);
            entity.Property(x => x.UpdatedAtUtc).HasColumnName("updated_at_utc");

            entity.HasOne(x => x.Run)
                .WithMany(x => x.Events)
                .HasForeignKey(x => x.RunUid)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(x => new { x.SiteId, x.CameraId, x.OccurredAtUtc }).HasDatabaseName("ix_events_site_camera_time");
            entity.HasIndex(x => x.Direction).HasDatabaseName("ix_events_direction");
            entity.HasIndex(x => x.ClassName).HasDatabaseName("ix_events_class_name");
        });

        modelBuilder.Entity<EventReview>(entity =>
        {
            entity.ToTable("event_reviews");
            entity.HasKey(x => x.EventUid);
            entity.Property(x => x.EventUid).HasColumnName("event_uid").HasMaxLength(64);
            entity.Property(x => x.ReviewStatus).HasColumnName("review_status").HasMaxLength(20);
            entity.Property(x => x.ReviewedAtUtc).HasColumnName("reviewed_at_utc");
            entity.Property(x => x.ReviewedBy).HasColumnName("reviewed_by").HasMaxLength(120);
            entity.Property(x => x.Notes).HasColumnName("notes");
            entity.Property(x => x.UpdatedAtUtc).HasColumnName("updated_at_utc");

            entity.HasOne(x => x.Event)
                .WithOne(x => x.Review)
                .HasForeignKey<EventReview>(x => x.EventUid)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(x => x.ReviewStatus).HasDatabaseName("ix_event_reviews_status");
        });

        modelBuilder.Entity<CameraCriteria>(entity =>
        {
            entity.ToTable("camera_criteria");
            entity.HasKey(x => new { x.SiteId, x.CameraId });
            entity.Property(x => x.SiteId).HasColumnName("site_id").HasMaxLength(100);
            entity.Property(x => x.CameraId).HasColumnName("camera_id").HasMaxLength(100);
            entity.Property(x => x.CriteriaTitle).HasColumnName("criteria_title").HasMaxLength(200);
            entity.Property(x => x.CriteriaDescription).HasColumnName("criteria_description");
            entity.Property(x => x.UpdatedAtUtc).HasColumnName("updated_at_utc");
        });
    }
}
